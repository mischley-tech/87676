package com.hoenn.raltspet

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

class RaltsOverlayService : Service() {

    companion object {
        const val ACTION_STOP_OVERLAY = "com.hoenn.raltspet.ACTION_STOP_OVERLAY"
        private const val CHANNEL_ID = "ralts_screen_walker_channel"
        private const val NOTIF_ID = 280

        @Volatile
        var isRunning: Boolean = false
    }

    private var windowManager: WindowManager? = null
    private var walkerView: RaltsWalkerView? = null
    private lateinit var layoutParams: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_OVERLAY) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        startForegroundSafely()

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val density = resources.displayMetrics.density
        val boxW = (130 * density).toInt()
        val boxH = (150 * density).toInt()

        layoutParams = WindowManager.LayoutParams(
            boxW,
            boxH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (resources.displayMetrics.widthPixels - boxW) / 2
            y = (resources.displayMetrics.heightPixels * 0.62f).toInt()
        }

        walkerView = RaltsWalkerView(this)
        try {
            windowManager?.addView(walkerView, layoutParams)
        } catch (_: Exception) {
            stopSelf()
            return
        }
        RaltsWidgetProvider.updateAllWidgets(this)
    }

    private fun startForegroundSafely() {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Ralts Screen Walker",
                NotificationManager.IMPORTANCE_LOW
            )
            nm.createNotificationChannel(channel)

            val stopIntent = Intent(this, RaltsOverlayService::class.java).apply {
                action = ACTION_STOP_OVERLAY
            }
            val stopPending = PendingIntent.getService(
                this, 99, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notif = Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Ralts is walking on your screen")
                .setContentText("Tap Ralts to pet, drag to move, or double-tap Ralts to recall.")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(stopPending)
                .setOngoing(true)
                .build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ID, notif)
            }
        } catch (_: Exception) {
            // Overlay WindowManager still runs if foreground promotion is restricted
        }
    }

    override fun onDestroy() {
        isRunning = false
        handler.removeCallbacksAndMessages(null)
        walkerView?.let {
            try {
                windowManager?.removeView(it)
            } catch (_: Exception) {}
        }
        walkerView = null
        RaltsWidgetProvider.updateAllWidgets(this)
        super.onDestroy()
    }

    /**
     * Custom interactive pixel-art view that renders Ralts walking around the screen,
     * bobbing, jumping when petted, and emitting floating hearts!
     */
    inner class RaltsWalkerView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val spritePaint = Paint().apply { isAntiAlias = false; isFilterBitmap = false }
        private val bubbleBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E60F291E")
            style = Paint.Style.FILL
        }
        private val bubbleBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#52B788")
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 26f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        private val heartPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F472B6")
            textSize = 34f
            textAlign = Paint.Align.CENTER
        }

        private var vx = 4f
        private var vy = 0.8f
        private var facingRight = true
        private var isPaused = false
        private var pauseTicks = 0
        private var tickCount = 0
        private var petHappyTicks = 0
        private var bubbleText = "Ralts! 💚"

        // Touch & drag tracking
        private var isDragging = false
        private var downRawX = 0f
        private var downRawY = 0f
        private var startParamX = 0
        private var startParamY = 0
        private var lastTapMs = 0L

        private val loopRunnable = object : Runnable {
            override fun run() {
                if (!isRunning) return
                stepAnimation()
                invalidate()
                handler.postDelayed(this, 40L) // 25 FPS smooth pixel animation
            }
        }

        init {
            handler.post(loopRunnable)
        }

        private fun stepAnimation() {
            tickCount++
            if (petHappyTicks > 0) {
                petHappyTicks--
            }

            if (isDragging) return

            // Pause occasionally to look around like a real Pokemon pet
            if (isPaused) {
                pauseTicks--
                if (pauseTicks <= 0) {
                    isPaused = false
                    vx = (if (Random.nextBoolean()) 1 else -1) * Random.nextInt(3, 6).toFloat()
                    vy = Random.nextInt(-2, 3).toFloat() * 0.6f
                    facingRight = vx >= 0
                }
                return
            } else if (petHappyTicks == 0 && Random.nextInt(140) == 0) {
                isPaused = true
                pauseTicks = Random.nextInt(30, 65)
                return
            }

            val dm = resources.displayMetrics
            val maxX = dm.widthPixels - width
            val minY = (dm.heightPixels * 0.12f).toInt()
            val maxY = (dm.heightPixels * 0.82f).toInt()

            var nextX = layoutParams.x + vx.toInt()
            var nextY = layoutParams.y + vy.toInt()

            if (nextX <= 0) {
                nextX = 0
                vx = abs(vx)
                facingRight = true
            } else if (nextX >= maxX) {
                nextX = maxX
                vx = -abs(vx)
                facingRight = false
            }

            if (nextY <= minY) {
                nextY = minY
                vy = abs(vy)
            } else if (nextY >= maxY) {
                nextY = maxY
                vy = -abs(vy)
            }

            layoutParams.x = nextX
            layoutParams.y = nextY
            try {
                windowManager?.updateViewLayout(this, layoutParams)
            } catch (_: Exception) {}
        }

        private fun triggerPetAction() {
            val prefs = context.getSharedPreferences("ralts_emerald_prefs", Context.MODE_PRIVATE)
            val happy = min(100, prefs.getInt("happiness", 85) + 12)
            val species = prefs.getString("species", "RALTS") ?: "RALTS"
            val nickname = prefs.getString("nickname", "")?.ifBlank { species } ?: species

            prefs.edit()
                .putInt("happiness", happy)
                .putLong("last_decay_ms", System.currentTimeMillis())
                .putBoolean("widget_dirty", true)
                .apply()

            petHappyTicks = 40 // ~1.6 seconds of heart particles & jumping
            val phrases = arrayOf(
                "$nickname loves it! 💚",
                "Happy: $happy%! ✨",
                "Ralts-ralts! 💖",
                "So cozy! 🌿"
            )
            bubbleText = phrases[Random.nextInt(phrases.size)]
            RaltsWidgetProvider.updateAllWidgets(context)
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val prefs = context.getSharedPreferences("ralts_emerald_prefs", Context.MODE_PRIVATE)
            val stage = prefs.getInt("stage", 0)
            val isShiny = prefs.getBoolean("isShiny", false)

            // Walk stride frame (alternates every 6 ticks when walking)
            val walkFrame = if (isDragging || petHappyTicks > 0) {
                (tickCount / 3) % 2
            } else if (!isPaused) {
                (tickCount / 6) % 2
            } else {
                0
            }

            val baseBmp = RaltsWidgetProvider.renderGen3SpriteBitmap(stage, isShiny, walkFrame)
            val finalBmp: Bitmap = if (facingRight) {
                val m = Matrix().apply { preScale(-1f, 1f) }
                Bitmap.createBitmap(baseBmp, 0, 0, baseBmp.width, baseBmp.height, m, false)
            } else {
                baseBmp
            }

            val bounceY = when {
                petHappyTicks > 0 -> -abs(sin(tickCount * 0.45f) * 22f)
                isDragging -> sin(tickCount * 0.5f) * 8f
                !isPaused -> -abs(sin(tickCount * 0.35f) * 8f)
                else -> 0f
            }

            // Draw soft shadow underneath Ralts
            paint.color = Color.parseColor("#55000000")
            val shadowOval = RectF(width * 0.25f, height - 24f, width * 0.75f, height - 10f)
            canvas.drawOval(shadowOval, paint)

            // Draw Ralts sprite
            val spriteSize = (width * 0.72f).toInt()
            val left = (width - spriteSize) / 2f
            val top = height - spriteSize - 16f + bounceY
            val dstRect = RectF(left, top, left + spriteSize, top + spriteSize)
            canvas.drawBitmap(finalBmp, null, dstRect, spritePaint)

            // Draw floating hearts & speech bubble when petted!
            if (petHappyTicks > 0) {
                val floatOffset = (40 - petHappyTicks) * 1.4f
                canvas.drawText("💚", width * 0.25f, top + 10f - floatOffset, heartPaint)
                canvas.drawText("💖", width * 0.75f, top + 20f - floatOffset * 0.8f, heartPaint)
                canvas.drawText("✨", width * 0.50f, top - 4f - floatOffset * 1.1f, heartPaint)

                val bubbleRect = RectF(8f, 6f, width - 8f, 48f)
                canvas.drawRoundRect(bubbleRect, 18f, 18f, bubbleBgPaint)
                canvas.drawRoundRect(bubbleRect, 18f, 18f, bubbleBorderPaint)
                canvas.drawText(bubbleText, width / 2f, 35f, textPaint)
            }
        }

        @SuppressLint("ClickableViewAccessibility")
        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startParamX = layoutParams.x
                    startParamY = layoutParams.y
                    isDragging = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (abs(dx) > 18f || abs(dy) > 18f) {
                        isDragging = true
                        layoutParams.x = (startParamX + dx).toInt()
                        layoutParams.y = (startParamY + dy).toInt()
                        try {
                            windowManager?.updateViewLayout(this, layoutParams)
                        } catch (_: Exception) {}
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        val now = System.currentTimeMillis()
                        if (now - lastTapMs < 350L) {
                            Toast.makeText(
                                context,
                                "🏠 Ralts returned to your Home Screen Widget!",
                                Toast.LENGTH_SHORT
                            ).show()
                            stopSelf()
                        } else {
                            triggerPetAction()
                        }
                        lastTapMs = now
                    }
                    isDragging = false
                    return true
                }
            }
            return super.onTouchEvent(event)
        }
    }
}
