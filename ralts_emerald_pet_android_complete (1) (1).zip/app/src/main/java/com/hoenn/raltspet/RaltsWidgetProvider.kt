package com.hoenn.raltspet

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.provider.Settings
import android.widget.RemoteViews
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class RaltsWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_QUICK_FEED = "com.hoenn.raltspet.ACTION_QUICK_FEED"
        const val ACTION_QUICK_PET = "com.hoenn.raltspet.ACTION_QUICK_PET"
        const val ACTION_STEP_WALK = "com.hoenn.raltspet.ACTION_STEP_WALK"
        const val ACTION_SCREEN_WALK = "com.hoenn.raltspet.ACTION_SCREEN_WALK"

        private val GEN3_RALTS = arrayOf(
            ".........KKKK...........",
            "........KRRRRK..........",
            ".......KRPPPPRK.........",
            "......KRPPPRRRBK........",
            "....KKKRRRRBBBBKKK......",
            "...KGGGKKKKKKKKGGDK.....",
            "..KGLLLLGGGGGGGGGGDK....",
            ".KGLLLLLGGGGGGGGGGGDK...",
            ".KGLLLGGGGGGGGGGGGGDK...",
            "KGGLLGGGGGGGGGGGGGGGDK..",
            "KGGGGGGGGGGGGGGGGGGGGK..",
            "KGGGGDDDDDDDDDDDDGGGGK..",
            ".KDDDDKWWWWWWWWKDDDDK...",
            "..KKKK.KWWWWWWK.KKKK....",
            "......KWWWWWWWWSK.......",
            ".....KWWWWWWWWWWSK......",
            "....KWWWKWWWWKWWWSK.....",
            "....KWWK.KWWWSKWWWSK....",
            "....KKK.KWWWWWSK.KKK....",
            ".......KWWWWWWWSK.......",
            "......KWWWWWWWWSSK......",
            "......KWWWKWWKWWSSK.....",
            "......KKKK.KK.KKKK......",
            "........................"
        )

        private val GEN3_KIRLIA = arrayOf(
            "....KKKK........KKKK....",
            "...KRRRRK..KK..KRRRRK...",
            "..KRPPPPRKGGGGKRPPPPRK..",
            "..KRRRRBBGLLLLGBBRRRRK..",
            "...KKKKGGGLLLLGGGGKKKK..",
            "....KGGGGGGGGGGGGGGDK...",
            "...KGGGGGEEGGGGEEGGGDK..",
            "...KGGGDDDDDDDDDDDDGDK..",
            "..KGGDKWWWWWWWWWWWWKDGDK",
            "..KGGK..KWWWWWWWWSK.KGDK",
            "..KGDK.KWWWWWWWWWWSK.KDK",
            "..KDK.KWWWKWWWWKWWWSK.KK",
            "...K..KWWK.KWWK.KWWK....",
            "......KKK.KGGGGK.KKK....",
            "........KKGGLLGGKK......",
            ".......KGGGGGGGGGGDK....",
            "......KGGGDDDDDDGGGDK...",
            "......KKKKKKKKKKKKKKK...",
            "........KWWWK.KWWSSK....",
            "........KWWK...KWWK.....",
            "........KWWK...KWWK.....",
            "........KWWK...KWWK.....",
            "........KKK.....KKK.....",
            "........................"
        )

        private val GEN3_GARDEVOIR = arrayOf(
            ".......KKKKKKKK.........",
            ".....KKGGGGGGGGKK.......",
            "....KGLLLLLLLLGGGDK.....",
            "...KGLLLGGGGGGGGGGDK....",
            "..KGGLLGGGGGGGGGGGGDK...",
            "..KGGGGGEEGGGGEEGGGGK...",
            "...KDDDDWWWWWWWWDDDDK...",
            ".....KKKWWWWWWWWSKKK....",
            "......KWWWRRRRWWWSK.....",
            "....KKGGGGRPPPRGGGGKK...",
            "...KGGGGGGGRBRGGGGGGDK..",
            "..KGGDKWWWWWWWWWWWKDGDK.",
            "....KK.KWWWWWWWWWWSK.KK.",
            "......KWWWWWWWWWWWSSK...",
            ".....KWWWWWWWWWWWWWSSK..",
            "....KWWWWWWWWWWWWWWWSSK.",
            "...KWWWWWWWWWWWWWWWWWSSK",
            "...KWWWWWWWWWWWWWWWWSSSK",
            "..KWWWWWWKWWWWWKWWWWWSSK",
            "..KWWWWWK.KWWWK.KWWWWSSK",
            "..KWWWWK..KWWWK..KWWWSSK",
            "...KKKK....KKK....KKKKK.",
            "........................",
            "........................"
        )

        fun renderGen3SpriteBitmap(stage: Int, isShiny: Boolean, walkFrame: Int = 0): Bitmap {
            val scale = 6
            val size = 24 * scale
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            val paint = Paint().apply { isAntiAlias = false }

            val palette = mapOf(
                'K' to Color.parseColor("#182018"),
                'W' to Color.parseColor("#F8F8F8"),
                'S' to Color.parseColor("#D0D0E0"),
                'G' to Color.parseColor(if (isShiny) "#6898F8" else "#68C050"),
                'L' to Color.parseColor(if (isShiny) "#A8D0FF" else "#98E880"),
                'D' to Color.parseColor(if (isShiny) "#3860B8" else "#408830"),
                'R' to Color.parseColor(if (isShiny) "#F89830" else "#F85870"),
                'P' to Color.parseColor(if (isShiny) "#FFD080" else "#FFA0B0"),
                'B' to Color.parseColor(if (isShiny) "#B85810" else "#B82840"),
                'E' to Color.parseColor("#D82848")
            )

            val matrix = when (stage) {
                1 -> GEN3_KIRLIA
                2 -> GEN3_GARDEVOIR
                else -> GEN3_RALTS
            }

            for (r in matrix.indices) {
                val row = matrix[r]
                // Subtle walking step shift on bottom rows (feet/skirt)
                val xShift = if (walkFrame == 1 && r >= 19) (if (r % 2 == 0) 1 else -1) else 0
                val yShift = if (walkFrame == 1 && r < 19) -1 else 0
                for (c in row.indices) {
                    val ch = row[c]
                    val color = palette[ch] ?: continue
                    paint.color = color
                    val drawC = c + xShift
                    val drawR = r + yShift
                    if (drawC in 0..23 && drawR in 0..23) {
                        canvas.drawRect(
                            (drawC * scale).toFloat(),
                            (drawR * scale).toFloat(),
                            ((drawC + 1) * scale).toFloat(),
                            ((drawR + 1) * scale).toFloat(),
                            paint
                        )
                    }
                }
            }
            return bmp
        }

        /**
         * Renders the interactive Route 102 walking strip inside the Home Screen Widget,
         * positioning Ralts at `walkSlot` (0..4) with direction, walking stride, and pet hearts!
         */
        fun renderHabitatSceneBitmap(
            stage: Int,
            isShiny: Boolean,
            walkSlot: Int,
            facingRight: Boolean,
            walkFrame: Int,
            justPetted: Boolean
        ): Bitmap {
            val w = 360
            val h = 156
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)

            // Sky / Emerald Route 102 gradient backdrop
            paint.color = Color.parseColor("#123124")
            canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)

            // Distant Emerald hills
            paint.color = Color.parseColor("#1B4332")
            canvas.drawOval(RectF(-30f, 70f, 180f, 160f), paint)
            canvas.drawOval(RectF(140f, 62f, 390f, 160f), paint)

            // Grassy walking path
            paint.color = Color.parseColor("#2D6A4F")
            canvas.drawRect(0f, 114f, w.toFloat(), h.toFloat(), paint)
            paint.color = Color.parseColor("#40916C")
            for (gx in 12 until w step 28) {
                canvas.drawRect(gx.toFloat(), 110f, (gx + 10).toFloat(), 116f, paint)
            }

            // Compute Ralts horizontal position across the 5 walking slots
            val clampedSlot = walkSlot.coerceIn(0, 4)
            val xPositions = intArrayOf(18, 68, 120, 172, 222)
            val spriteX = xPositions[clampedSlot].toFloat()
            val spriteY = if (justPetted) 8f else (if (walkFrame == 1) 14f else 18f)

            val rawSprite = renderGen3SpriteBitmap(stage, isShiny, walkFrame)
            val orientedSprite = if (facingRight) {
                val m = Matrix().apply { preScale(-1f, 1f) }
                Bitmap.createBitmap(rawSprite, 0, 0, rawSprite.width, rawSprite.height, m, false)
            } else {
                rawSprite
            }

            // Ground shadow under Ralts
            paint.color = Color.parseColor("#55000000")
            canvas.drawOval(RectF(spriteX + 28f, 124f, spriteX + 92f, 138f), paint)

            val spritePaint = Paint().apply { isAntiAlias = false; isFilterBitmap = false }
            val dst = RectF(spriteX, spriteY, spriteX + 118f, spriteY + 118f)
            canvas.drawBitmap(orientedSprite, null, dst, spritePaint)

            // Draw pixel hearts if Ralts was just petted!
            if (justPetted) {
                paint.color = Color.parseColor("#F472B6")
                paint.textSize = 26f
                paint.isFakeBoldText = true
                canvas.drawText("♥", spriteX + 12f, spriteY + 26f, paint)
                paint.color = Color.parseColor("#6EE7B7")
                canvas.drawText("♥", spriteX + 94f, spriteY + 18f, paint)
                paint.color = Color.parseColor("#FDE047")
                paint.textSize = 20f
                canvas.drawText("✦", spriteX + 56f, spriteY + 10f, paint)
            }

            // Helpful bottom-right caption inside habitat
            paint.color = Color.parseColor("#B3ECFDF5")
            paint.textSize = 18f
            paint.isFakeBoldText = true
            canvas.drawText("Tap Ralts to Pet! 👋", 14f, 146f, paint)

            return bmp
        }

        fun applyElapsedDecay(context: Context) {
            val prefs = context.getSharedPreferences("ralts_emerald_prefs", Context.MODE_PRIVATE)
            val now = System.currentTimeMillis()
            val lastMs = prefs.getLong("last_decay_ms", 0L)
            if (lastMs == 0L) {
                prefs.edit().putLong("last_decay_ms", now).apply()
                return
            }
            val elapsedMinutes = (now - lastMs) / (1000L * 60L)
            if (elapsedMinutes >= 15L) {
                val intervals = (elapsedMinutes / 15L).toInt()
                val currentHunger = prefs.getInt("hunger", 84)
                val currentHappy = prefs.getInt("happiness", 88)
                val newHunger = max(0, currentHunger - (intervals * 2))
                val happyDrop = if (newHunger < 30) intervals * 2 else intervals * 1
                val newHappy = max(0, currentHappy - happyDrop)

                prefs.edit()
                    .putInt("hunger", newHunger)
                    .putInt("happiness", newHappy)
                    .putLong("last_decay_ms", lastMs + intervals * 15L * 60L * 1000L)
                    .putBoolean("widget_dirty", true)
                    .apply()
            }
        }

        private fun stepWalkPosition(prefs: android.content.SharedPreferences, petted: Boolean) {
            var slot = prefs.getInt("walk_slot", 2)
            var dirRight = prefs.getBoolean("walk_dir_right", true)
            val frame = (prefs.getInt("walk_frame", 0) + 1) % 2

            if (dirRight) {
                slot++
                if (slot >= 4) {
                    slot = 4
                    dirRight = false
                }
            } else {
                slot--
                if (slot <= 0) {
                    slot = 0
                    dirRight = true
                }
            }

            prefs.edit()
                .putInt("walk_slot", slot)
                .putBoolean("walk_dir_right", dirRight)
                .putInt("walk_frame", frame)
                .putBoolean("just_petted", petted)
                .apply()
        }

        fun updateAllWidgets(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, RaltsWidgetProvider::class.java))
            val intent = Intent(context, RaltsWidgetProvider::class.java).apply {
                action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
            }
            context.sendBroadcast(intent)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val prefs = context.getSharedPreferences("ralts_emerald_prefs", Context.MODE_PRIVATE)
        when (intent.action) {
            ACTION_QUICK_FEED -> {
                applyElapsedDecay(context)
                val hunger = min(100, prefs.getInt("hunger", 80) + 22)
                var level = prefs.getInt("level", 5) + 1
                var stage = prefs.getInt("stage", 0)
                if (stage == 0 && level >= 20) stage = 1
                if (stage == 1 && level >= 30) stage = 2
                val species = when (stage) {
                    1 -> "KIRLIA"
                    2 -> "GARDEVOIR"
                    else -> "RALTS"
                }
                stepWalkPosition(prefs, petted = false)
                prefs.edit()
                    .putInt("hunger", hunger)
                    .putInt("level", level)
                    .putInt("stage", stage)
                    .putString("species", species)
                    .putLong("last_decay_ms", System.currentTimeMillis())
                    .putBoolean("widget_dirty", true)
                    .apply()
                updateAllWidgets(context)
            }
            ACTION_QUICK_PET -> {
                applyElapsedDecay(context)
                val happy = min(100, prefs.getInt("happiness", 85) + 12)
                stepWalkPosition(prefs, petted = true)
                prefs.edit()
                    .putInt("happiness", happy)
                    .putLong("last_decay_ms", System.currentTimeMillis())
                    .putBoolean("widget_dirty", true)
                    .apply()
                updateAllWidgets(context)
            }
            ACTION_STEP_WALK -> {
                stepWalkPosition(prefs, petted = false)
                updateAllWidgets(context)
            }
            ACTION_SCREEN_WALK -> {
                if (RaltsOverlayService.isRunning) {
                    context.stopService(Intent(context, RaltsOverlayService::class.java))
                } else if (Settings.canDrawOverlays(context)) {
                    context.startService(Intent(context, RaltsOverlayService::class.java))
                } else {
                    val permIntent = Intent(context, MainActivity::class.java).apply {
                        action = MainActivity.ACTION_START_SCREEN_WALKER
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    }
                    context.startActivity(permIntent)
                }
                updateAllWidgets(context)
            }
        }
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        applyElapsedDecay(context)
        val prefs = context.getSharedPreferences("ralts_emerald_prefs", Context.MODE_PRIVATE)
        val stage = prefs.getInt("stage", 0)
        val species = prefs.getString("species", "RALTS") ?: "RALTS"
        val nickname = prefs.getString("nickname", "")?.ifBlank { species } ?: species
        val level = prefs.getInt("level", 5)
        val hunger = prefs.getInt("hunger", 84)
        val happiness = prefs.getInt("happiness", 88)
        val isShiny = prefs.getBoolean("isShiny", false)
        val walkSlot = prefs.getInt("walk_slot", Random.nextInt(0, 5))
        val facingRight = prefs.getBoolean("walk_dir_right", true)
        val walkFrame = prefs.getInt("walk_frame", 0)
        val justPetted = prefs.getBoolean("just_petted", false)

        val moodStatus = when {
            justPetted -> "💚 $nickname loved your headpat! (+12% Happy)"
            hunger < 30 -> "⚠️ Hungry! Feed an Oran Berry"
            happiness < 35 -> "💭 Lonely! Tap Ralts to pet"
            RaltsOverlayService.isRunning -> "🚶 Walking on your Pixel screen!"
            else -> "🌿 Strolling along Route 102"
        }

        for (appWidgetId in appWidgetIds) {
            val openAppIntent = Intent(context, MainActivity::class.java)
            val openPending = PendingIntent.getActivity(
                context, 0, openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val feedIntent = Intent(context, RaltsWidgetProvider::class.java).apply {
                action = ACTION_QUICK_FEED
            }
            val feedPending = PendingIntent.getBroadcast(
                context, 1, feedIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val petIntent = Intent(context, RaltsWidgetProvider::class.java).apply {
                action = ACTION_QUICK_PET
            }
            val petPending = PendingIntent.getBroadcast(
                context, 2, petIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val walkStepIntent = Intent(context, RaltsWidgetProvider::class.java).apply {
                action = ACTION_STEP_WALK
            }
            val walkStepPending = PendingIntent.getBroadcast(
                context, 3, walkStepIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val screenWalkIntent = Intent(context, RaltsWidgetProvider::class.java).apply {
                action = ACTION_SCREEN_WALK
            }
            val screenWalkPending = PendingIntent.getBroadcast(
                context, 4, screenWalkIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val views = RemoteViews(context.packageName, R.layout.ralts_widget)
            val shinyPrefix = if (isShiny) "✨ " else ""
            views.setTextViewText(R.id.widget_title, "$shinyPrefix$nickname ($species Lv.$level) ↗")
            views.setTextViewText(R.id.widget_stats, "Fullness: $hunger%  •  Happy: $happiness%")
            views.setTextViewText(R.id.widget_mood, moodStatus)
            views.setTextViewText(
                R.id.btn_widget_screen_walk,
                if (RaltsOverlayService.isRunning) "🏠 Recall" else "🚶 Screen Walk"
            )
            views.setProgressBar(R.id.widget_hunger_bar, 100, hunger, false)
            views.setProgressBar(R.id.widget_happy_bar, 100, happiness, false)

            val sceneBmp = renderHabitatSceneBitmap(
                stage = stage,
                isShiny = isShiny,
                walkSlot = walkSlot,
                facingRight = facingRight,
                walkFrame = walkFrame,
                justPetted = justPetted
            )
            views.setImageViewBitmap(R.id.widget_sprite, sceneBmp)

            // Tapping the Ralts habitat directly pets Ralts & makes it walk!
            views.setOnClickPendingIntent(R.id.widget_sprite, petPending)
            // Tapping the top title row opens the full Ralts app
            views.setOnClickPendingIntent(R.id.widget_title, openPending)
            views.setOnClickPendingIntent(R.id.btn_widget_feed, feedPending)
            views.setOnClickPendingIntent(R.id.btn_widget_pet, petPending)
            views.setOnClickPendingIntent(R.id.btn_widget_walk, walkStepPending)
            views.setOnClickPendingIntent(R.id.btn_widget_screen_walk, screenWalkPending)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }
}
