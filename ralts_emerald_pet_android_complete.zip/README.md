# Ralts Emerald Pet — Complete Google Pixel Android App & Home Screen Widget

This is the complete, fixed Android project (`com.hoenn.raltspet`) for your **Google Pixel**.

## What Was Fixed From Your Original Zip
Your original `.zip` was missing several required Android build and resource files that prevented it from compiling into an `.apk`:
1. **Added Home Screen Widget Layout & Metadata**:
   - `app/src/main/res/layout/ralts_widget.xml` (Emerald PokéNav widget card with pixel sprite, fullness/happiness bars, mood status, and **🍇 Feed** / **💚 Pet** buttons)
   - `app/src/main/res/xml/ralts_widget_info.xml` (4x2 resizable Pixel home screen widget configuration)
   - `app/src/main/res/drawable/*.xml` & `app/src/main/res/mipmap-*/ic_launcher.png` (Gen 3 Ralts pixel-art app icons and widget preview graphic)
2. **Added Root Gradle Build Configuration**:
   - `settings.gradle.kts`, root `build.gradle.kts`, `gradle.properties`, and `gradle/wrapper/gradle-wrapper.properties`
3. **Added All-Day Hunger & Happiness Care Decay on the Widget**:
   - `RaltsWidgetProvider.kt` now tracks real elapsed time throughout the day (`applyElapsedDecay`) so Ralts gets hungry (~8% per hour) and needs attention right on your Pixel home screen, and evolves into **Kirlia (Lv. 20)** and **Gardevoir (Lv. 30)**.
4. **Added 1-Click Cloud APK Builder (`.github/workflows/build-apk.yml`)**:
   - Lets you compile the `.apk` automatically for free on GitHub without installing Android Studio on a computer.

---

## Option A: Build the APK in the Cloud via GitHub (Easiest — No Software Install Required)

If you don't want to download and install Android Studio (~4 GB), GitHub will build the `.apk` for you automatically in ~2 minutes:

1. Unzip `ralts_emerald_pet_android_complete.zip` into a folder on your computer or phone.
2. Sign in to [GitHub](https://github.com) and create a **New Repository** (name it `ralts-emerald-pet`, can be Private or Public).
3. Click **uploading an existing file**, drag and drop **all files and folders** from the unzipped folder (`app/`, `gradle/`, `.github/`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, `README.md`), and click **Commit changes**.
4. Click the **Actions** tab at the top of your GitHub repository.
5. You will see the **Build Ralts Emerald Pet APK** workflow running. Wait ~2 minutes for the green checkmark ✅.
6. Click the completed workflow run, scroll down to **Artifacts**, and download **`RaltsEmeraldPet-Pixel-APK`** (unzip it to get `app-debug.apk`).

---

## Option B: Build the APK on Your Computer with Android Studio

1. Download and install [Android Studio](https://developer.android.com/studio).
2. Unzip `ralts_emerald_pet_android_complete.zip`.
3. Open Android Studio, click **Open**, and select the unzipped folder.
4. Wait ~1–2 minutes for Gradle Sync to finish at the bottom right.
5. In the top menu bar, click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. When the notification pops up in the bottom-right corner, click **locate** to find `app-debug.apk` (inside `app/build/outputs/apk/debug/app-debug.apk`).

---

## How to Install the APK & Add the Widget on Your Google Pixel

1. **Install the APK**:
   - Transfer or download `app-debug.apk` onto your Pixel and tap it in the **Files by Google** app.
   - If prompted, toggle on **Allow from this source** (install unknown apps) and tap **Install**.
   - If Google Play Protect shows an "Unrecognized app" prompt (normal for personal debug APKs), tap **More details > Install anyway**.
2. **Initialize Your Ralts**:
   - Open **Ralts Emerald Pet** once from your app drawer so it initializes your Ralts on Route 102.
3. **Pin the Widget to Your Pixel Home Screen**:
   - Long-press an empty space on your Pixel home screen and tap **Widgets**.
   - Scroll down to **Ralts Emerald Pet**, touch and hold the **Ralts Emerald Pet Widget**, and drag it onto your home screen!
