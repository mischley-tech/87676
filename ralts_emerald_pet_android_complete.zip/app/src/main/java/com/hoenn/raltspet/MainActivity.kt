package com.hoenn.raltspet

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var webView: WebView

    inner class AndroidWidgetBridge(private val context: Context) {
        @JavascriptInterface
        fun updateWidgetData(
            nickname: String,
            species: String,
            level: Int,
            stage: Int,
            hunger: Int,
            happiness: Int,
            isShiny: Boolean
        ) {
            val prefs = context.getSharedPreferences("ralts_emerald_prefs", Context.MODE_PRIVATE)
            prefs.edit()
                .putString("nickname", nickname)
                .putString("species", species)
                .putInt("level", level)
                .putInt("stage", stage)
                .putInt("hunger", hunger)
                .putInt("happiness", happiness)
                .putBoolean("isShiny", isShiny)
                .putLong("last_decay_ms", System.currentTimeMillis())
                .putBoolean("widget_dirty", false)
                .apply()
            RaltsWidgetProvider.updateAllWidgets(context)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false

        webView.addJavascriptInterface(AndroidWidgetBridge(this), "AndroidWidgetBridge")
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                syncFromWidgetIfNeeded()
            }
        }
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        RaltsWidgetProvider.applyElapsedDecay(this)
        syncFromWidgetIfNeeded()
    }

    private fun syncFromWidgetIfNeeded() {
        val prefs = getSharedPreferences("ralts_emerald_prefs", Context.MODE_PRIVATE)
        if (prefs.getBoolean("widget_dirty", false)) {
            val level = prefs.getInt("level", 5)
            val stage = prefs.getInt("stage", 0)
            val hunger = prefs.getInt("hunger", 84)
            val happiness = prefs.getInt("happiness", 88)
            prefs.edit().putBoolean("widget_dirty", false).apply()
            webView.evaluateJavascript(
                "if(window.receiveWidgetSync){window.receiveWidgetSync($level,$stage,$hunger,$happiness);}",
                null
            )
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
