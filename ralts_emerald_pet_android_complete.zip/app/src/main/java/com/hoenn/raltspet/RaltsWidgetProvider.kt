package com.hoenn.raltspet

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.widget.RemoteViews
import kotlin.math.max
import kotlin.math.min

class RaltsWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_QUICK_FEED = "com.hoenn.raltspet.ACTION_QUICK_FEED"
        const val ACTION_QUICK_PET = "com.hoenn.raltspet.ACTION_QUICK_PET"

        private val GEN3_RALTS = arrayOf(
            ".........KKKK...........",
            "........KRRRRK..........",
            ".......KRPPPPRK.........",
            "......KRPPPRRRBK........",
            "....KKKRRRRBBBBKKK......",
            "...KGGGKKKKKKKKGGDK.....",
            "..KGLLLLGGGGGGGGGGDK....",
            ".KGLLLLLGGGGGGGGGGGDK...",
            ".KGLLLGGGGGGGGGGGGGDK...",
            "KGGLLGGGGGGGGGGGGGGGDK..",
            "KGGGGGGGGGGGGGGGGGGGGK..",
            "KGGGGDDDDDDDDDDDDGGGGK..",
            ".KDDDDKWWWWWWWWKDDDDK...",
            "..KKKK.KWWWWWWK.KKKK....",
            "......KWWWWWWWWSK.......",
            ".....KWWWWWWWWWWSK......",
            "....KWWWKWWWWKWWWSK.....",
            "....KWWK.KWWWSKWWWSK....",
            "....KKK.KWWWWWSK.KKK....",
            ".......KWWWWWWWSK.......",
            "......KWWWWWWWWSSK......",
            "......KWWWKWWKWWSSK.....",
            "......KKKK.KK.KKKK......",
            "........................"
        )

        private val GEN3_KIRLIA = arrayOf(
            "....KKKK........KKKK....",
            "...KRRRRK..KK..KRRRRK...",
            "..KRPPPPRKGGGGKRPPPPRK..",
            "..KRRRRBBGLLLLGBBRRRRK..",
            "...KKKKGGGLLLLGGGGKKKK..",
            "....KGGGGGGGGGGGGGGDK...",
            "...KGGGGGEEGGGGEEGGGDK..",
            "...KGGGDDDDDDDDDDDDGDK..",
            "..KGGDKWWWWWWWWWWWWKDGDK",
            "..KGGK..KWWWWWWWWSK.KGDK",
            "..KGDK.KWWWWWWWWWWSK.KDK",
            "..KDK.KWWWKWWWWKWWWSK.KK",
            "...K..KWWK.KWWK.KWWK....",
            "......KKK.KGGGGK.KKK....",
            "........KKGGLLGGKK......",
            ".......KGGGGGGGGGGDK....",
            "......KGGGDDDDDDGGGDK...",
            "......KKKKKKKKKKKKKKK...",
            "........KWWWK.KWWSSK....",
            "........KWWK...KWWK.....",
            "........KWWK...KWWK.....",
            "........KWWK...KWWK.....",
            "........KKK.....KKK.....",
            "........................"
        )

        private val GEN3_GARDEVOIR = arrayOf(
            ".......KKKKKKKK.........",
            ".....KKGGGGGGGGKK.......",
            "....KGLLLLLLLLGGGDK.....",
            "...KGLLLGGGGGGGGGGDK....",
            "..KGGLLGGGGGGGGGGGGDK...",
            "..KGGGGGEEGGGGEEGGGGK...",
            "...KDDDDWWWWWWWWDDDDK...",
            ".....KKKWWWWWWWWSKKK....",
            "......KWWWRRRRWWWSK.....",
            "....KKGGGGRPPPRGGGGKK...",
            "...KGGGGGGGRBRGGGGGGDK..",
            "..KGGDKWWWWWWWWWWWKDGDK.",
            "....KK.KWWWWWWWWWWSK.KK.",
            "......KWWWWWWWWWWWSSK...",
            ".....KWWWWWWWWWWWWWSSK..",
            "....KWWWWWWWWWWWWWWWSSK.",
            "...KWWWWWWWWWWWWWWWWWSSK",
            "...KWWWWWWWWWWWWWWWWSSSK",
            "..KWWWWWWKWWWWWKWWWWWSSK",
            "..KWWWWWK.KWWWK.KWWWWSSK",
            "..KWWWWK..KWWWK..KWWWSSK",
            "...KKKK....KKK....KKKKK.",
            "........................",
            "........................"
        )

        fun renderGen3SpriteBitmap(stage: Int, isShiny: Boolean): Bitmap {
            val scale = 6
            val size = 24 * scale
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            val paint = Paint().apply { isAntiAlias = false }

            val palette = mapOf(
                'K' to Color.parseColor("#182018"),
                'W' to Color.parseColor("#F8F8F8"),
                'S' to Color.parseColor("#D0D0E0"),
                'G' to Color.parseColor(if (isShiny) "#6898F8" else "#68C050"),
                'L' to Color.parseColor(if (isShiny) "#A8D0FF" else "#98E880"),
                'D' to Color.parseColor(if (isShiny) "#3860B8" else "#408830"),
                'R' to Color.parseColor(if (isShiny) "#F89830" else "#F85870"),
                'P' to Color.parseColor(if (isShiny) "#FFD080" else "#FFA0B0"),
                'B' to Color.parseColor(if (isShiny) "#B85810" else "#B82840"),
                'E' to Color.parseColor("#D82848")
            )

            val matrix = when (stage) {
                1 -> GEN3_KIRLIA
                2 -> GEN3_GARDEVOIR
                else -> GEN3_RALTS
            }

            for (r in matrix.indices) {
                val row = matrix[r]
                for (c in row.indices) {
                    val ch = row[c]
                    val color = palette[ch] ?: continue
                    paint.color = color
                    canvas.drawRect(
                        (c * scale).toFloat(),
                        (r * scale).toFloat(),
                        ((c + 1) * scale).toFloat(),
                        ((r + 1) * scale).toFloat(),
                        paint
                    )
                }
            }
            return bmp
        }

        /**
         * Simulates natural hunger & happiness decay throughout the day based on elapsed real time
         * (~8% hunger and ~5% happiness per hour, checked every 15+ minutes).
         */
        fun applyElapsedDecay(context: Context) {
            val prefs = context.getSharedPreferences("ralts_emerald_prefs", Context.MODE_PRIVATE)
            val now = System.currentTimeMillis()
            val lastMs = prefs.getLong("last_decay_ms", 0L)
            if (lastMs == 0L) {
                prefs.edit().putLong("last_decay_ms", now).apply()
                return
            }
            val elapsedMinutes = (now - lastMs) / (1000L * 60L)
            if (elapsedMinutes >= 15L) {
                val intervals = (elapsedMinutes / 15L).toInt()
                val currentHunger = prefs.getInt("hunger", 84)
                val currentHappy = prefs.getInt("happiness", 88)
                val newHunger = max(0, currentHunger - (intervals * 2))
                val happyDrop = if (newHunger < 30) intervals * 2 else intervals * 1
                val newHappy = max(0, currentHappy - happyDrop)

                prefs.edit()
                    .putInt("hunger", newHunger)
                    .putInt("happiness", newHappy)
                    .putLong("last_decay_ms", lastMs + intervals * 15L * 60L * 1000L)
                    .putBoolean("widget_dirty", true)
                    .apply()
            }
        }

        fun updateAllWidgets(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, RaltsWidgetProvider::class.java))
            val intent = Intent(context, RaltsWidgetProvider::class.java).apply {
                action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
            }
            context.sendBroadcast(intent)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val prefs = context.getSharedPreferences("ralts_emerald_prefs", Context.MODE_PRIVATE)
        if (intent.action == ACTION_QUICK_FEED) {
            applyElapsedDecay(context)
            val hunger = min(100, prefs.getInt("hunger", 80) + 22)
            var level = prefs.getInt("level", 5) + 1
            var stage = prefs.getInt("stage", 0)
            if (stage == 0 && level >= 20) stage = 1
            if (stage == 1 && level >= 30) stage = 2
            val species = when (stage) {
                1 -> "KIRLIA"
                2 -> "GARDEVOIR"
                else -> "RALTS"
            }
            prefs.edit()
                .putInt("hunger", hunger)
                .putInt("level", level)
                .putInt("stage", stage)
                .putString("species", species)
                .putLong("last_decay_ms", System.currentTimeMillis())
                .putBoolean("widget_dirty", true)
                .apply()
            updateAllWidgets(context)
        } else if (intent.action == ACTION_QUICK_PET) {
            applyElapsedDecay(context)
            val happy = min(100, prefs.getInt("happiness", 85) + 12)
            prefs.edit()
                .putInt("happiness", happy)
                .putLong("last_decay_ms", System.currentTimeMillis())
                .putBoolean("widget_dirty", true)
                .apply()
            updateAllWidgets(context)
        }
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        applyElapsedDecay(context)
        val prefs = context.getSharedPreferences("ralts_emerald_prefs", Context.MODE_PRIVATE)
        val stage = prefs.getInt("stage", 0)
        val species = prefs.getString("species", "RALTS") ?: "RALTS"
        val nickname = prefs.getString("nickname", "")?.ifBlank { species } ?: species
        val level = prefs.getInt("level", 5)
        val hunger = prefs.getInt("hunger", 84)
        val happiness = prefs.getInt("happiness", 88)
        val isShiny = prefs.getBoolean("isShiny", false)

        val moodStatus = when {
            hunger < 30 -> "⚠️ Hungry! Needs an Oran Berry"
            happiness < 35 -> "💭 Lonely! Give a headpat"
            hunger >= 80 && happiness >= 80 -> "✨ Feeling happy & well-fed!"
            else -> "🌿 Exploring Route 102 peacefully"
        }

        for (appWidgetId in appWidgetIds) {
            val openAppIntent = Intent(context, MainActivity::class.java)
            val openPending = PendingIntent.getActivity(
                context, 0, openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val feedIntent = Intent(context, RaltsWidgetProvider::class.java).apply {
                action = ACTION_QUICK_FEED
            }
            val feedPending = PendingIntent.getBroadcast(
                context, 1, feedIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val petIntent = Intent(context, RaltsWidgetProvider::class.java).apply {
                action = ACTION_QUICK_PET
            }
            val petPending = PendingIntent.getBroadcast(
                context, 2, petIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val views = RemoteViews(context.packageName, R.layout.ralts_widget)
            val shinyPrefix = if (isShiny) "✨ " else ""
            views.setTextViewText(R.id.widget_title, "$shinyPrefix$nickname ($species Lv.$level)")
            views.setTextViewText(R.id.widget_stats, "Fullness: $hunger%  •  Happy: $happiness%")
            views.setTextViewText(R.id.widget_mood, moodStatus)
            views.setProgressBar(R.id.widget_hunger_bar, 100, hunger, false)
            views.setProgressBar(R.id.widget_happy_bar, 100, happiness, false)
            views.setImageViewBitmap(R.id.widget_sprite, renderGen3SpriteBitmap(stage, isShiny))

            views.setOnClickPendingIntent(R.id.widget_root, openPending)
            views.setOnClickPendingIntent(R.id.widget_sprite, openPending)
            views.setOnClickPendingIntent(R.id.btn_widget_feed, feedPending)
            views.setOnClickPendingIntent(R.id.btn_widget_pet, petPending)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }
}
